$(document).ready(function(e){
  $('h6').on('click',function(){
     $('.social').stop().slideToggle();
  });
})